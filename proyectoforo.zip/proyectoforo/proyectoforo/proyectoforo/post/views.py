from django.shortcuts import render, redirect, get_object_or_404
from .models import Categoria, Tema, Comentario
from .forms import TemaForm, ComentarioForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import UserRegistrationForm


def categoria_list(request):
    categorias = Categoria.objects.all()
    return render(request, 'post/categoria_list.html', {'categorias': categorias})

def tema_list(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    temas = Tema.objects.filter(categoria=categoria)
    return render(request, 'post/tema_list.html', {'categoria': categoria, 'temas': temas})

@login_required
def tema_create(request):
    if request.method == "POST":
        form = TemaForm(request.POST)
        if form.is_valid():
            tema = form.save(commit=False)
            tema.autor = request.user
            tema.save()
            return redirect('categoria_list')
    else:
        form = TemaForm()
    return render(request, 'post/tema_form.html', {'form': form})

def tema_detail(request, pk):
    tema = get_object_or_404(Tema, pk=pk)
    comentarios = tema.comentarios.all()
    return render(request, 'post/tema_detail.html', {'tema': tema, 'comentarios': comentarios})

@login_required
def comentario_create(request, pk):
    tema = get_object_or_404(Tema, pk=pk)
    if request.method == "POST":
        
        form = ComentarioForm(request.POST)
        if form.is_valid():
               comentario = form.save(commit=False)
               comentario.tema = tema
               comentario.autor = request.user
               comentario.save()
               return redirect('tema_detail', pk=tema.pk)
    else:
           form = ComentarioForm()
    return render(request, 'post/comentario_form.html', {'form': form, 'tema': tema})

def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('categoria_list')
    return render(request, 'post/login.html')

def logout_view(request):
    logout(request)
    return redirect('categoria_list')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)  # Iniciar sesión automáticamente después del registro
            return redirect('categoria_list')  # Redirigir a la lista de categorías
    else:
        form = UserRegistrationForm()
    return render(request, 'post/register.html', {'form': form})

