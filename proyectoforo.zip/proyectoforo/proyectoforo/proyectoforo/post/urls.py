from django.urls import path
from . import views

urlpatterns = [
    path('', views.categoria_list, name='categoria_list'),
    path('categoria/<int:pk>/', views.tema_list, name='tema_list'),
    path('tema/new/', views.tema_create, name='tema_create'),
    path('tema/<int:pk>/', views.tema_detail, name='tema_detail'),
    path('tema/<int:pk>/comment/', views.comentario_create, name='comentario_create'),
    path('accounts/login/', views.login_view, name='login'),
    path('accounts/logout/', views.logout_view, name='logout'),
    path('register/', views.register, name='register'),
]